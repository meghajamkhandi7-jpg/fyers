# ScreenReaderStatusMessage Utility

A React/TypeScript utility component designed to help applications meet WCAG 2.1 AA SC 4.1.3 Status Messages requirements.

## Features

- Provides proper ARIA role and live region attributes for screen reader announcements
- Queues multiple status messages to prevent interference
- Supports both string and React element messages
- Optional visible rendering mode that hides text from accessibility tree to prevent duplication
- Fully tested against WCAG Technique ARIA22 requirements

## Installation

```bash
npm install
```

## Usage

### Basic Usage (Screen Reader Only)

```jsx
import ScreenReaderStatusMessage from './ScreenReaderStatusMessage';

// In your component
<ScreenReaderStatusMessage message="13 search results found" />
```

### Visible Text Mode

When you need to display the status message visually but want to avoid duplication in screen readers:

```jsx
<ScreenReaderStatusMessage 
  message="13 search results found" 
  visible={true} 
/>
```

This will render the message visibly while also providing a separate announcement for screen readers.

## Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `message` | `string \| React.ReactNode` | Required | The status message to announce |
| `visible` | `boolean` | `false` | Whether to render the message visibly (hidden from accessibility tree) |
| `role` | `string` | `'status'` | ARIA role for the container |
| `ariaLive` | `'polite' \| 'assertive'` | `'polite'` | ARIA live region politeness level |

## Testing

The component includes comprehensive tests that validate compliance with WCAG requirements:

1. ✅ Container has role="status" before message occurs
2. ✅ Status message is contained within the role="status" container
3. ✅ Equivalent information elements reside in the container
4. ✅ Visible prop functionality works correctly

Run tests with:
```bash
npm test
```

## WCAG Compliance

This utility helps meet WCAG 2.1 AA Success Criterion 4.1.3: Status Messages by ensuring that status updates are programmatically determinable and announced to assistive technologies without interfering with the user's current activity.
