import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import sinon from 'sinon';
import ScreenReaderStatusMessage from './ScreenReaderStatusMessage';

describe('ScreenReaderStatusMessage', () => {
  beforeEach(() => {
    // Clear any existing timers
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  test('1. Container has role attribute with value of status before status message occurs', () => {
    render(<ScreenReaderStatusMessage message="" />);

    const container = screen.getByRole('status');
    expect(container).toBeInTheDocument();
    expect(container).toHaveAttribute('role', 'status');
  });

  test('2. When status message is triggered, it is inside the container', async () => {
    const testMessage = '13 search results found';
    render(<ScreenReaderStatusMessage message={testMessage} />);

    // Wait for the message to be rendered
    await waitFor(() => {
      expect(screen.getByText(testMessage)).toBeInTheDocument();
    });

    const container = screen.getByRole('status');
    expect(container).toContainElement(screen.getByText(testMessage));
  });

  test('3. Elements providing equivalent information reside in the container', () => {
    const messageWithElement = <span data-testid="cart-info">3 items in cart</span>;
    render(<ScreenReaderStatusMessage message={messageWithElement} />);

    const container = screen.getByRole('status');
    const infoElement = screen.getByTestId('cart-info');
    expect(container).toContainElement(infoElement);
  });

  test('4. Existing text can be wrapped without visually affecting it using visible prop', () => {
    const visibleMessage = 'Search results: 13 items';
    render(<ScreenReaderStatusMessage message={visibleMessage} visible={true} />);

    // Check that visible text is rendered
    const visibleText = screen.getByText(visibleMessage);
    expect(visibleText).toBeInTheDocument();
    expect(visibleText).toHaveAttribute('aria-hidden', 'true');

    // Check that screen reader only text is also present
    const srContainer = screen.getByRole('status');
    expect(srContainer).toBeInTheDocument();
  });
});
