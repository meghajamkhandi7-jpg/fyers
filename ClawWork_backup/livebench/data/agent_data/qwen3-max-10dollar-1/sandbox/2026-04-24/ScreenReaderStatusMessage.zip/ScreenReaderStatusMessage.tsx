import React, { useEffect, useState } from 'react';
import './ScreenReaderStatusMessage.css';

interface ScreenReaderStatusMessageProps {
  message: string | React.ReactNode;
  visible?: boolean;
  role?: string;
  ariaLive?: 'polite' | 'assertive';
}

const ScreenReaderStatusMessage: React.FC<ScreenReaderStatusMessageProps> = ({
  message,
  visible = false,
  role = 'status',
  ariaLive = 'polite'
}) => {
  const [messages, setMessages] = useState<(string | React.ReactNode)[]>([]);

  useEffect(() => {
    if (message) {
      setMessages(prev => [...prev, message]);

      // Clean up messages after they've been announced (optional cleanup)
      const timer = setTimeout(() => {
        setMessages(prev => prev.slice(1));
      }, 5000);

      return () => clearTimeout(timer);
    }
  }, [message]);

  return (
    <div className="screen-reader-status-container">
      {/* Status message container for screen readers */}
      <div 
        role={role}
        aria-live={ariaLive}
        className="sr-only"
      >
        {messages.map((msg, index) => (
          <div key={index} className="sr-message">
            {msg}
          </div>
        ))}
      </div>

      {/* Visible text that is hidden from accessibility tree */}
      {visible && (
        <span aria-hidden="true" className="sr-visible-text">
          {message}
        </span>
      )}
    </div>
  );
};

export default ScreenReaderStatusMessage;
